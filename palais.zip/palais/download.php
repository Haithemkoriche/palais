<?php
session_start();
include('connect.php');
require('C:\xampp64\htdocs\fpdf\fpdf.php');
$pdf = new FPDF('P', 'mm', 'A4');
$q = count($_SESSION['id']);
$v = $_SESSION['id'];
for ($i = 0; $i < $q; $i++) {
  $pdf->AddPage();
  $query = mysqli_query($connect, "SELECT * FROM `client` WHERE `id`=$v[$i]");
  while ($row = mysqli_fetch_array($query)) {
    $array = array();
    $array["Id"] = $row["id"];
    $array["Nom"] = $row["nom"];
    $array["Prenom"] = $row["prenom"];
    $array["Email"] = $row["email"];
    $array["Numero"] = $row["numero_telephon"];
    $array["Addres"] = $row["addres"];
    $array["Addres2"] = $row["addres2"];
    $array["Wilaya"] = $row["wilaya"];
    $array["Commun"] = $row["commun"];
    $array["Produit"] = $row["produit"];
    $array["Prix_produit"] = $row["prix_produit"];
    $array["Prix_livraison"] = $row["prix_livraison"];
    $array["Prix_total"] = $row["prix_total"];

    ob_start();
    $pdf->image('logo.png', 10, 20, 100);
    $pdf->image('logo1.png', 120, 10, 80);
    $pdf->Ln(20);
    $pdf->Ln(20);
    $pdf->SetFont('Arial', 'B', 15);
    $pdf->Cell(50);
    $pdf->Ln(50);
    $pdf->Cell(30, 10, 'Expediteur', 0, 'C');
    $pdf->Ln(0);
    $pdf->Cell(50);
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(30, 10, 'Palais Des Parfums', 0, 'C');
    $pdf->Cell(30, 10, 'Baba Hassen,Alger', 0, 'C');
    $pdf->Cell(30, 10, '0770548622/0553091115', 0, 'C');
    $pdf->Ln(0);
    $pdf->SetFont('Arial', 'B', 11);
    $pdf->Cell(40, 10, "Destinataire :");
    $pdf->Ln(6);
    foreach ($array as $key => $value) {
      $pdf->Cell(40, 10, $key . " : " . $value);
      $pdf->Ln(6);
    }
    $pdf->Ln(300);
  }
}
$pdf->Output();
ob_end_flush();
