<?php
include("connect.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>KORICHE HAITHEM</title>
  <link rel="stylesheet" href="stylee.css">
  <link rel="stylesheet" href="../fontawesome-free-6.2.1-web/css/solid.css">
  <link rel="stylesheet" href="../fontawesome-free-6.2.1-web/css/all.css">
</head>

<body>
  <nav>
    <div class="logo">SAYCOM</div>
    <ul class="list">
      <li><a href="">Acceuil</a></li>
      <li><a href="check/checkout/index.html">Ajouter</a></li>
    </ul>

  </nav>
  <section>
    <form action="" method="post">
      <?php
      echo "<table>";
      echo "<thead>
      <th>Les Client</th>
      </thead>";
      $query = mysqli_query($connect, "SELECT * FROM `client`");
      session_start();
      while ($row = mysqli_fetch_array($query)) {
        echo "<tr><td> <input type='checkbox' name='choix[]' value=" . $row["id"] . " >" . $row['nom'] . " " . $row['prenom'];
        echo "<div class='a'><a href='download.php' name='download'> <i class='fa fa-download' onclick='download()'></i> </a> ";
        if ($row["status"] == 0) {
          echo "<a href=''><i class='fa fa-edit'></i></a></div></td>
            </tr>";
        }
      }
      if (isset($_POST['submit'])) {
        $_SESSION["id"] = $_POST["choix"];
        // header("location: download.php");
        // exit;
      }
      if (isset($_post))
        echo "</table>";
      mysqli_close($connect);
      ?>
    </form>
  </section>
  <script>
    var element = document.querySelectorAll('body > form > table > tbody > tr > td > input[type=checkbox]');
    let i = 0;
    element.forEach(item => {
      if (item.checked) {
        consol.log(i)
      }
      i++;
    })
  </script>
</body>

</html>