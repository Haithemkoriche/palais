<?php
$user = "root";
$password = "";
$dsn = "adel";
$server = "localhost";
$connect = mysqli_connect($server, $user, $password, $dsn);
if (mysqli_connect_errno()) {
  echo "ERROR" . mysqli_connect_error();
}
// mysqli_close($connect);
