<?php
session_start();
require('C:\xampp64\htdocs\fpdf\fpdf.php');

class PDF extends FPDF
{
  // En-tête
  function Header()
  {

    $this->image('logo.jpeg', 10, 5);

    $this->SetFont('Arial', 'B', 15);
    // Décalage à droite
    $this->Cell(80);
    // Titre
    $this->Cell(30, 10, 'Recu', 1, 0, 'C');
    // Saut de ligne
    $this->Ln(20);
    $this->Ln(20);
    $this->Cell(50);
    $this->SetFont('Arial', 'B', 20);
    $this->Cell(100, 15, 'Recu De Commande', "TB", 0, 'C');
    $this->Ln(20);
    $this->SetFont('Arial', 'B', 15);
    $this->Cell(30, 10, "Nom : " . $_SESSION["name"], 0, 'C');
    $this->Cell(30, 10, "Prenom : " . $_SESSION["prenom"], 0, 'C');
    $this->Cell(30, 10, "Email : " . $_SESSION["email"], 0, 'C');
    $this->Cell(30, 10, "Addr : " . $_SESSION["addr"], 0, 'C');
    if (isset($_SESSION["addr2"])) {

      $this->Cell(30, 10, "Addr2 : " . $_SESSION["addr2"], 0, 'C');
    }
    $this->Cell(30, 10, "Wilaya : " . $_SESSION["wilaya"], 0, 'C');
    $this->Cell(30, 10, "Commun : " . $_SESSION["commun"], 0, 'C');
    $this->Cell(30, 10, "produit : " . $_SESSION["produit"], 0, 'C');
    $this->Cell(30, 10, "prix de produit : " . $_SESSION["prix_produit"], 0, 'C');
    $this->Cell(30, 10, "prix de livraison : " . $_SESSION["Prix_livraison"], 0, 'C');
    $this->Cell(30, 10, "Total : " . $_SESSION["total"], 0, 'C');
  }
}
// Instanciation de la classe dérivée
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Times', '', 12);
$pdf->Output();
