<?php
session_start();
if (isset($_POST["submit"])) {
  $nom = $_POST["nom"];
  $prenom = $_POST["prenom"];
  $email = $_POST["email"];
  $phone = $_POST["phone"];
  $addr = $_POST["addr"];
  $addr2 = $_POST["addr2"];
  $wilaya = $_POST["wilaya"];
  $prix = $_POST["prix"];
  $total = $wilaya + $prix;
  $commun = $_POST["commune"];
  $produit = $_POST["produit"];
  $id = $phone;
  if ($wilaya == 400) {
    $livraison = "ALGER";
  } elseif ($wilaya == 500) {
    $livraison = "BLIDA";
  } elseif ($wilaya == 700) {
    $livraison = "BOUMERDAS";
  } elseif ($wilaya == 700) {
    $livraison = "TIPAZA";
  }


  $host = "localhost";
  $username = "root";
  $password = "";
  $database = "adel";
  $dsn = 'mysql:host=localhost;dbname=adel';
  $dsn1 = 'mysql:host=localhost;dbname=countries';

  $db = new PDO($dsn, $username, $password, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_NUM
  ]);
  $q = "INSERT INTO `client`(`id`, `nom`, `prenom`, `email`,`numero_telephon`, `addres`, `addres2`, `wilaya`, `commun`, `produit`,`prix_produit`,`prix_livraison`,`prix_total`) VALUES ('$id','$nom','$prenom','$email','$phone','$addr','$addr2','$livraison','$commun','$produit','$prix','$wilaya','$total')";
  $db->exec($q);
  $db = null;




  header("location: ../../../../index.php");
  exit();
  // header("location: fact.php");
  // exit();
}
